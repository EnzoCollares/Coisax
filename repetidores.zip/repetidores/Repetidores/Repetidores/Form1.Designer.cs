﻿namespace Repetidores
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BtnWhile = new Button();
            BtnDoWhile = new Button();
            BtnFor = new Button();
            BtnForeach = new Button();
            BtnContinue = new Button();
            BtnBreak = new Button();
            BtnGoogle = new Button();
            BtnCalc = new Button();
            BtnNotepad = new Button();
            BtnUser = new Button();
            LstMostra = new ListBox();
            SuspendLayout();
            // 
            // BtnWhile
            // 
            BtnWhile.Location = new Point(76, 119);
            BtnWhile.Name = "BtnWhile";
            BtnWhile.Size = new Size(112, 50);
            BtnWhile.TabIndex = 0;
            BtnWhile.Text = "While";
            BtnWhile.UseVisualStyleBackColor = true;
            BtnWhile.Click += BtnWhile_Click;
            // 
            // BtnDoWhile
            // 
            BtnDoWhile.Location = new Point(76, 175);
            BtnDoWhile.Name = "BtnDoWhile";
            BtnDoWhile.Size = new Size(112, 50);
            BtnDoWhile.TabIndex = 1;
            BtnDoWhile.Text = "Do While";
            BtnDoWhile.UseVisualStyleBackColor = true;
            BtnDoWhile.Click += BtnDoWhile_Click;
            // 
            // BtnFor
            // 
            BtnFor.Location = new Point(76, 232);
            BtnFor.Name = "BtnFor";
            BtnFor.Size = new Size(112, 50);
            BtnFor.TabIndex = 2;
            BtnFor.Text = "For";
            BtnFor.UseVisualStyleBackColor = true;
            BtnFor.Click += BtnFor_Click;
            // 
            // BtnForeach
            // 
            BtnForeach.Location = new Point(76, 289);
            BtnForeach.Name = "BtnForeach";
            BtnForeach.Size = new Size(112, 50);
            BtnForeach.TabIndex = 3;
            BtnForeach.Text = "Foreach";
            BtnForeach.UseVisualStyleBackColor = true;
            // 
            // BtnContinue
            // 
            BtnContinue.Location = new Point(76, 343);
            BtnContinue.Name = "BtnContinue";
            BtnContinue.Size = new Size(112, 50);
            BtnContinue.TabIndex = 4;
            BtnContinue.Text = "Continue";
            BtnContinue.UseVisualStyleBackColor = true;
            // 
            // BtnBreak
            // 
            BtnBreak.Location = new Point(206, 119);
            BtnBreak.Name = "BtnBreak";
            BtnBreak.Size = new Size(112, 50);
            BtnBreak.TabIndex = 5;
            BtnBreak.Text = "Break";
            BtnBreak.UseVisualStyleBackColor = true;
            // 
            // BtnGoogle
            // 
            BtnGoogle.Location = new Point(206, 175);
            BtnGoogle.Name = "BtnGoogle";
            BtnGoogle.Size = new Size(112, 50);
            BtnGoogle.TabIndex = 6;
            BtnGoogle.Text = "Google";
            BtnGoogle.UseVisualStyleBackColor = true;
            // 
            // BtnCalc
            // 
            BtnCalc.Location = new Point(206, 232);
            BtnCalc.Name = "BtnCalc";
            BtnCalc.Size = new Size(112, 50);
            BtnCalc.TabIndex = 7;
            BtnCalc.Text = "Calculadora";
            BtnCalc.UseVisualStyleBackColor = true;
            // 
            // BtnNotepad
            // 
            BtnNotepad.Location = new Point(206, 289);
            BtnNotepad.Name = "BtnNotepad";
            BtnNotepad.Size = new Size(112, 50);
            BtnNotepad.TabIndex = 8;
            BtnNotepad.Text = "Notepad";
            BtnNotepad.UseVisualStyleBackColor = true;
            // 
            // BtnUser
            // 
            BtnUser.Location = new Point(206, 343);
            BtnUser.Name = "BtnUser";
            BtnUser.Size = new Size(112, 50);
            BtnUser.TabIndex = 9;
            BtnUser.Text = "Usuário";
            BtnUser.UseVisualStyleBackColor = true;
            // 
            // LstMostra
            // 
            LstMostra.FormattingEnabled = true;
            LstMostra.Location = new Point(417, 66);
            LstMostra.Name = "LstMostra";
            LstMostra.Size = new Size(312, 354);
            LstMostra.TabIndex = 10;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(825, 553);
            Controls.Add(LstMostra);
            Controls.Add(BtnUser);
            Controls.Add(BtnNotepad);
            Controls.Add(BtnCalc);
            Controls.Add(BtnGoogle);
            Controls.Add(BtnBreak);
            Controls.Add(BtnContinue);
            Controls.Add(BtnForeach);
            Controls.Add(BtnFor);
            Controls.Add(BtnDoWhile);
            Controls.Add(BtnWhile);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button BtnWhile;
        private Button BtnDoWhile;
        private Button BtnFor;
        private Button BtnForeach;
        private Button BtnContinue;
        private Button BtnBreak;
        private Button BtnGoogle;
        private Button BtnCalc;
        private Button BtnNotepad;
        private Button BtnUser;
        private ListBox LstMostra;
    }
}
