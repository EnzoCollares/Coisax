namespace Repetidores
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnWhile_Click(object sender, EventArgs e)
        {
            int numero = 0;

            LstMostra.Items.Clear();
            while (numero <= 100)
            {
                if (numero % 2 != 0)
                {
                    LstMostra.Items.Add(numero);
                }
                numero++;
            }
        }

        private void BtnDoWhile_Click(object sender, EventArgs e)
        {
            int num = 0;

            LstMostra.Items.Clear();
            do
            {
                LstMostra.Items.Add(num);
                num += 5;
            } while (num <= 100);
        }

        private void BtnFor_Click(object sender, EventArgs e)
        {
            LstMostra.Items.Clear();
            for (int i = 0; i <= 10; i++)
            {
                int res = i * 9;
                LstMostra.Items.Add(9 + "X" + i + "=" + res);
            }
        }
    }
}
