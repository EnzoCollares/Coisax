﻿namespace SisPadoca
{
    partial class FrmProdutos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmProdutos));
            LblNCM = new Label();
            LblDescricao = new Label();
            LblCodigoBarras = new Label();
            LblUniMedida = new Label();
            LblLote = new Label();
            PbxImagem = new PictureBox();
            comboBox1 = new ComboBox();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            BtnNovo = new Button();
            BtnEditar = new Button();
            BtnExcluir = new Button();
            BtnLimpar = new Button();
            BtnFechar = new Button();
            ImgLista = new ImageList(components);
            ((System.ComponentModel.ISupportInitialize)PbxImagem).BeginInit();
            SuspendLayout();
            // 
            // LblNCM
            // 
            LblNCM.AutoSize = true;
            LblNCM.Location = new Point(506, 26);
            LblNCM.Name = "LblNCM";
            LblNCM.Size = new Size(52, 25);
            LblNCM.TabIndex = 0;
            LblNCM.Text = "NCM";
            // 
            // LblDescricao
            // 
            LblDescricao.AutoSize = true;
            LblDescricao.Location = new Point(506, 146);
            LblDescricao.Name = "LblDescricao";
            LblDescricao.Size = new Size(88, 25);
            LblDescricao.TabIndex = 1;
            LblDescricao.Text = "Descrição";
            // 
            // LblCodigoBarras
            // 
            LblCodigoBarras.AutoSize = true;
            LblCodigoBarras.Location = new Point(506, 247);
            LblCodigoBarras.Name = "LblCodigoBarras";
            LblCodigoBarras.Size = new Size(149, 25);
            LblCodigoBarras.TabIndex = 2;
            LblCodigoBarras.Text = "Codigo de Barras";
            // 
            // LblUniMedida
            // 
            LblUniMedida.AutoSize = true;
            LblUniMedida.Location = new Point(837, 146);
            LblUniMedida.Name = "LblUniMedida";
            LblUniMedida.Size = new Size(168, 25);
            LblUniMedida.TabIndex = 3;
            LblUniMedida.Text = "Unidade de Medida";
            // 
            // LblLote
            // 
            LblLote.AutoSize = true;
            LblLote.Location = new Point(837, 259);
            LblLote.Name = "LblLote";
            LblLote.Size = new Size(46, 25);
            LblLote.TabIndex = 4;
            LblLote.Text = "Lote";
            // 
            // PbxImagem
            // 
            PbxImagem.Image = (Image)resources.GetObject("PbxImagem.Image");
            PbxImagem.Location = new Point(30, 39);
            PbxImagem.Name = "PbxImagem";
            PbxImagem.Size = new Size(341, 433);
            PbxImagem.SizeMode = PictureBoxSizeMode.StretchImage;
            PbxImagem.TabIndex = 5;
            PbxImagem.TabStop = false;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Unitário", "Kilo", "Dúzia" });
            comboBox1.Location = new Point(837, 192);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(182, 33);
            comboBox1.TabIndex = 6;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(506, 67);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(150, 31);
            textBox1.TabIndex = 7;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(506, 192);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(324, 31);
            textBox2.TabIndex = 8;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(837, 301);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(150, 31);
            textBox3.TabIndex = 9;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(506, 301);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(325, 31);
            textBox4.TabIndex = 10;
            // 
            // BtnNovo
            // 
            BtnNovo.Location = new Point(456, 384);
            BtnNovo.Name = "BtnNovo";
            BtnNovo.Size = new Size(122, 51);
            BtnNovo.TabIndex = 11;
            BtnNovo.Text = "Novo";
            BtnNovo.UseVisualStyleBackColor = true;
            // 
            // BtnEditar
            // 
            BtnEditar.Location = new Point(584, 384);
            BtnEditar.Name = "BtnEditar";
            BtnEditar.Size = new Size(122, 51);
            BtnEditar.TabIndex = 12;
            BtnEditar.Text = "Editar";
            BtnEditar.UseVisualStyleBackColor = true;
            // 
            // BtnExcluir
            // 
            BtnExcluir.Location = new Point(712, 384);
            BtnExcluir.Name = "BtnExcluir";
            BtnExcluir.Size = new Size(122, 51);
            BtnExcluir.TabIndex = 13;
            BtnExcluir.Text = "Excluir";
            BtnExcluir.UseVisualStyleBackColor = true;
            // 
            // BtnLimpar
            // 
            BtnLimpar.Location = new Point(840, 384);
            BtnLimpar.Name = "BtnLimpar";
            BtnLimpar.Size = new Size(122, 51);
            BtnLimpar.TabIndex = 14;
            BtnLimpar.Text = "Limpar";
            BtnLimpar.UseVisualStyleBackColor = true;
            // 
            // BtnFechar
            // 
            BtnFechar.Location = new Point(968, 384);
            BtnFechar.Name = "BtnFechar";
            BtnFechar.Size = new Size(122, 51);
            BtnFechar.TabIndex = 15;
            BtnFechar.Text = "Fechar";
            BtnFechar.UseVisualStyleBackColor = true;
            // 
            // ImgLista
            // 
            ImgLista.ColorDepth = ColorDepth.Depth32Bit;
            ImgLista.ImageSize = new Size(16, 16);
            ImgLista.TransparentColor = Color.Transparent;
            // 
            // FrmProdutos
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1200, 596);
            Controls.Add(BtnFechar);
            Controls.Add(BtnLimpar);
            Controls.Add(BtnExcluir);
            Controls.Add(BtnEditar);
            Controls.Add(BtnNovo);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(comboBox1);
            Controls.Add(PbxImagem);
            Controls.Add(LblLote);
            Controls.Add(LblUniMedida);
            Controls.Add(LblCodigoBarras);
            Controls.Add(LblDescricao);
            Controls.Add(LblNCM);
            Name = "FrmProdutos";
            Text = "FrmProdutos";
            ((System.ComponentModel.ISupportInitialize)PbxImagem).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label LblNCM;
        private Label LblDescricao;
        private Label LblCodigoBarras;
        private Label LblUniMedida;
        private Label LblLote;
        private PictureBox PbxImagem;
        private ComboBox comboBox1;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private Button BtnNovo;
        private Button BtnEditar;
        private Button BtnExcluir;
        private Button BtnLimpar;
        private Button BtnFechar;
        private ImageList ImgLista;
    }
}